#include <stdio.h>
#define MAX 20

int graph[MAX][MAX];
int visited[MAX];

void init(int n){
    for(int i=1;i<=n;i++){
        visited[i]=0;
    }
}

void printing(int n){
    if(n==5){
        printf("등-");
    }
    else if(n==6){
        printf("어깨-");
    }
    else if(n==7){
        printf("플랭크 ");
    }
    else if(n==8){
        printf("스쿼트-");
    }
    else if(n==9){
        printf("데드리프트 ");
    }
    else if(n==10){
        printf("덤벨로우-");
    }
    else if(n==11){
        printf("덤벨 숄더프레스 ");
    }
    else if(n==12){
        printf("크런치 ");
    }
    else if(n==13){
        printf("레그익스텐션-");
    }
    else if(n==14){
        printf("랫풀다운-");
    }
}

void DFS(int cur, int n){
    visited[cur]=1;
    printing(cur);
    for(int i=1;i<=n;i++){
        if(graph[cur][i]==1 && visited[i]==0){
            DFS(i,n);
        }
    }
    return;
}

int main(){
    int start;
    char routine[20];

    graph[2][5]=1; graph[2][6]=1;
    graph[5][2]=1; graph[6][2]=1;

    graph[5][10]=1; graph[6][11]=1; graph[10][14]=1;
    graph[10][5]=1; graph[11][6]=1; graph[14][10]=1;

    graph[3][7]=1; graph[7][12]=1; 
    graph[7][3]=1; graph[12][7]=1;

    graph[4][8]=1; graph[8][13]=1; graph[4][9]=1;
    graph[8][4]=1; graph[13][8]=1; graph[9][4]=1;

    scanf("%s", routine);
    if(!strcmp(routine,"상체")){
        start=2;
    }
    else if(!strcmp(routine,"코어")){
        start=3;
    }
    else{
        start=4;
    }
    DFS(start, 14);
    return 0;
}

/*
               1
        2      3      4
      5   6    7     8   9
    10    11   12    13
  14


*/
